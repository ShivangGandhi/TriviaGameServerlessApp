const admin = require("firebase-admin");

var serviceAccount = require("serviceAccountKey.json");

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: 'serverless-project-392501',
});

exports.handler = async (event) => {
    try {
        if (!event.teamId) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Team ID is required' }),
            };
        }

        const db = admin.firestore();
        const teamPlayers = await db.collection('users').where('teamid', '==', event.teamId).get();

        if (!teamPlayers) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'Team not found' }),
            };
        }

        let teamTotal = 0;
        let teamTotalQuestions = 0;
        let teamTotalGamesPlayed = 0;
        let uniqueQuizIds = new Set();
        teamPlayers.forEach((teamPlayer) => {
            const quizzes = teamPlayer.data().quizzes;
            let playerTotal = 0;
            let playerTotalQuestions = 0;
            quizzes.forEach((quiz) => {
                if (quiz.quizscore && typeof quiz.quizscore === 'number'
                    && quiz.noOfQuestions && typeof quiz.noOfQuestions === 'number'
                    && quiz.quizid && typeof quiz.quizid === 'number') {
                    playerTotal += quiz.quizscore;
                    playerTotalQuestions += quiz.noOfQuestions;
                    uniqueQuizIds.add(quiz.quizid);
                }
            });
            teamTotal += playerTotal;
            teamTotalQuestions += playerTotalQuestions;
            teamTotalGamesPlayed += uniqueQuizIds.size;
        });

        const accuracy = teamTotal / teamTotalQuestions;
        const roundedAccuracy = accuracy.toFixed(2);

        return {
            statusCode: 200,
            body: JSON.stringify(
                {
                    'Team Total': `${teamTotal}`,
                    'Team Accuracy': `${roundedAccuracy}`,
                    'Team Total Games Played': `${teamTotalGamesPlayed}`
                }
            ),
        };
    } catch (error) {
        console.error('Error fetching total score:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error' }),
        };
    }
};