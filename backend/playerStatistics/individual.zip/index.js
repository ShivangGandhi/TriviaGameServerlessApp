const admin = require("firebase-admin");

var serviceAccount = require("serviceAccountKey.json");

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: 'serverless-project-392501',
});

exports.handler = async (event) => {
    try {
        if (!event.email) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'email is required' }),
            };
        }

        const db = admin.firestore();
        const docRef = db.collection('users').doc(event.email);
        const docSnapshot = await docRef.get();
        console.log(docSnapshot.data());

        if (!docSnapshot.exists) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'User not found' }),
            };
        } else {
            let totalScore = 0;
            let totalQuestions = 0;
            const quizzes = docSnapshot.data().quizzes;
            const totalGamesPlayed = quizzes.length;

            quizzes.forEach((quiz) => {
                if (quiz.quizscore && typeof quiz.quizscore === 'number'
                    && quiz.noOfQuestions && typeof quiz.noOfQuestions === 'number') {
                    totalScore += quiz.quizscore;
                    totalQuestions += quiz.noOfQuestions;
                }
            });

            const accuracy = totalScore / totalQuestions;
            const roundedAccuracy = accuracy.toFixed(2);

            return {
                statusCode: 200,
                body: JSON.stringify(
                    {
                        totalScore: `${totalScore}`,
                        accuracy: `${roundedAccuracy}`,
                        totalGamesPlayed: `${totalGamesPlayed}`
                    }
                ),
            };

        }
    } catch (error) {
        console.error('Error fetching total score:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error' }),
        };
    }
};